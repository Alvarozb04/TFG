#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
================================================================================
PROYECTO TFG: VQE GEMELO DIGITAL (20 Qubits) - GLICINA
================================================================================
Autor: Álvaro Zapata Beteta
Entorno: HPC / Clúster de Computación
Descripción: Simulación de química cuántica utilizando puertas físicas cfSim
             y optimización estocástica SPSA pura.
             Diseñado para ejecución paralela en CPU de alto rendimiento.
================================================================================
"""

import os
import sys
import json
import time
import argparse
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

# Qiskit imports
from qiskit import QuantumCircuit
from qiskit.quantum_info import SparsePauliOp, Statevector
from qiskit.circuit import ParameterVector, Gate
from qiskit.circuit.library import XXPlusYYGate, CPhaseGate
from qiskit_nature.second_q.mappers import JordanWignerMapper

# Manejo de FCIDump para diferentes versiones de Qiskit Nature
try:
    from qiskit_nature.second_q.formats.fcidump import FCIDump
except (ImportError, ModuleNotFoundError):
    from qiskit_nature.second_q.formats import FCIDump

# ==============================================================================
# 1. DEFINICIÓN DE PUERTAS CUÁNTICAS (cfSim)
# ==============================================================================
class FSimGate(Gate):
    """
    Implementación personalizada de la puerta cfSim (FSimGate).
    Combina XXPlusYY (iSWAP parcial) y CPhase. Conservadora de número de partículas.
    """
    def __init__(self, theta, phi, label=None):
        super().__init__("fsim", 2, [theta, phi], label=label)
        
    def _define(self):
        qc = QuantumCircuit(2)
        qc.append(XXPlusYYGate(2 * self.params[0], 0), [0, 1])
        qc.append(CPhaseGate(-self.params[1]), [0, 1])
        self.definition = qc

# ==============================================================================
# 2. NÚCLEO DEL PROBLEMA (Hamiltoniano y Ansatz)
# ==============================================================================
def load_qubit_hamiltonian(fcidump_path: str) -> SparsePauliOp:
    """Carga las integrales de FCIDump y las mapea a qubits."""
    if not os.path.exists(fcidump_path):
        raise FileNotFoundError(f"Archivo no encontrado: {fcidump_path}")
        
    fd = FCIDump.from_file(fcidump_path)
    
    try:
        from qiskit_nature.second_q.formats import fcidump_to_problem
        problem = fcidump_to_problem(fd)
        ferm_op = problem.hamiltonian.second_q_op()
    except Exception:
        if hasattr(fd, "to_problem"):
            problem = fd.to_problem()
            ferm_op = problem.hamiltonian.second_q_op()
        else:
            raise AttributeError("Error al procesar FCIDUMP. Revisa la versión de qiskit-nature.")

    # Mapeo Jordan-Wigner (20 qubits para Glicina)
    mapper = JordanWignerMapper()
    qubit_op = mapper.map(ferm_op)

    if not isinstance(qubit_op, SparsePauliOp):
        qubit_op = SparsePauliOp.from_list(qubit_op.to_list())
    return qubit_op

def build_cfsim_ansatz(bitstring: str, layers: int = 2):
    """Construye el ansatz del Gemelo Digital usando puertas físicas cfSim."""
    n = len(bitstring)
    qc = QuantumCircuit(n, name="cfSim_Ansatz")
    
    # Estado inicial Hartree-Fock
    for i, b in enumerate(bitstring):
        if b == "1": qc.x(i)

    # Parámetros: 2 por cada par de qubits (theta, phi)
    n_params = layers * n * 2
    theta_params = ParameterVector("p", n_params)

    k = 0
    for _ in range(layers):
        # Entrelazamiento en escalera lineal
        for q in range(n - 1):
            qc.append(FSimGate(theta_params[k], theta_params[k+1]), [q, q + 1])
            k += 2
        # Cierre del anillo (circular)
        qc.append(FSimGate(theta_params[k], theta_params[k+1]), [n - 1, 0])
        k += 2

    return qc, theta_params

def get_energy(op: SparsePauliOp, qc: QuantumCircuit) -> float:
    """Calcula el valor esperado de la energía usando Statevector."""
    # En máquinas HPC, Statevector se paralelizara automáticamente vía OMP_NUM_THREADS
    psi = Statevector(qc)
    return float(np.real(psi.expectation_value(op)))

# ==============================================================================
# 3. MOTOR DE OPTIMIZACIÓN SPSA
# ==============================================================================
def run_spsa_optimization(op, ansatz, theta0, maxiter, a_spsa, c_spsa, stability_a, alpha, gamma):
    """Optimización SPSA pura adaptada para ejecución masiva."""
    print(f"\n>>> INICIANDO OPTIMIZACIÓN SPSA ({maxiter} iteraciones)...")
    
    nparams = len(theta0)
    theta = theta0.copy()
    energies = []
    
    t_start = time.time()
    for k in range(1, maxiter + 1):
        # Programación de coeficientes SPSA mejorada
        ak = a_spsa / ((k + stability_a) ** alpha)
        ck = c_spsa / (k ** gamma)

        # Perturbación de Bernoulli
        delta = 2 * np.random.randint(0, 2, size=nparams) - 1
        
        # Evaluaciones gemelas
        e_plus = get_energy(op, ansatz.assign_parameters(theta + ck * delta))
        e_minus = get_energy(op, ansatz.assign_parameters(theta - ck * delta))

        # Gradiente estocástico
        ghat = (e_plus - e_minus) / (2.0 * ck) * delta.astype(float)
        
        # Actualización
        theta = theta - ak * ghat
        
        # Guardar progreso
        e_curr = get_energy(op, ansatz.assign_parameters(theta))
        energies.append(e_curr)

        # Frecuencia de log adaptativa
        log_freq = 5 if maxiter <= 500 else 50
        if k % log_freq == 0 or k == 1:
            avg_energy = np.mean(energies[-10:]) if len(energies) > 10 else e_curr
            print(f"    Iter {k:4d}/{maxiter} | E_actual: {e_curr:.8f} Ha | E_avg: {avg_energy:.8f} Ha")

    t_end = time.time()
    print(f"    [OK] SPSA completado en {t_end-t_start:.2f}s")
    return theta, energies

# ==============================================================================
# 4. FLUJO DE TRABAJO PRINCIPAL
# ==============================================================================
def main():
    parser = argparse.ArgumentParser(description="VQE cfSim Digital Twin (HPC Ready)")
    parser.add_argument('--layers', type=int, default=4, help='Número de capas cfSim (default: 4)')
    parser.add_argument('--iters', type=int, default=1000, help='Iteraciones SPSA (default: 1000)')
    parser.add_argument('--outdir', type=str, default='vqe_cfsim_out', help='Carpeta de salida')
    args = parser.parse_args()

    header = " VQE HYBRID WORKFLOW: PURE SPSA (HPC VERSION) "
    print("\n" + "="*70 + "\n" + header.center(70) + "\n" + "="*70)

    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    OUT_DIR = os.path.join(BASE_DIR, args.outdir)
    os.makedirs(OUT_DIR, exist_ok=True)
    
    FCIDUMP_FILE = os.path.join(BASE_DIR, "active_space.fcidump")
    VQE_INPUT_FILE = os.path.join(BASE_DIR, "vqe_input.json")

    # A. Carga de datos
    print("[+] Cargando configuración de entrada...")
    with open(VQE_INPUT_FILE, "r") as f:
        vqe_data = json.load(f)
        hf_bitstring = vqe_data["hf"]["bitstring_alpha_beta"]
    
    hamiltonian = load_qubit_hamiltonian(FCIDUMP_FILE)
    ansatz, params = build_cfsim_ansatz(hf_bitstring, layers=args.layers)
    
    print(f"    - Molécula    : Glicina")
    print(f"    - Qubits      : {ansatz.num_qubits}")
    print(f"    - Capas cfSim : {args.layers}")
    print(f"    - Parámetros  : {len(params)}")
    
    # B. Optimización
    np.random.seed(7)
    theta_init = np.random.uniform(-0.1, 0.1, size=len(params))
    
    # Ejecutar Optimización SPSA Pura con hiperparámetros robustos
    theta_final, history = run_spsa_optimization(
        op=hamiltonian, 
        ansatz=ansatz, 
        theta0=theta_init,
        maxiter=args.iters,
        a_spsa=0.1,
        c_spsa=0.1,
        stability_a=50,
        alpha=0.602,
        gamma=0.101
    )

    # C. Resultados finales
    e_final = history[-1]
    e_core = -258.3179  # Energía constante del core
    e_total = e_final + e_core

    print("\n" + "="*70)
    print(" RESULTADOS FINALES ".center(70))
    print("="*70)
    print(f" Energía Activa (Final)  : {e_final:.10f} Ha")
    print(f" Energía Total (Molécula): {e_total:.10f} Ha")
    print("="*70)

    # D. Guardar artefactos
    print("\n[+] Guardando resultados en:", OUT_DIR)
    
    plt.figure(figsize=(10, 6))
    plt.plot(history, color='#1f77b4', linewidth=2)
    plt.axhline(y=e_final, color='r', linestyle='--', alpha=0.5)
    plt.title(f"Convergencia VQE (Glicina - {ansatz.num_qubits} Qubits | {args.layers} Capas)")
    plt.xlabel("Iteraciones SPSA")
    plt.ylabel("Energía Activa (Ha)")
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(OUT_DIR, "convergencia_final.png"), dpi=200)
    
    with open(os.path.join(OUT_DIR, "circuito_ansatz.txt"), "w") as f:
        f.write(ansatz.draw(output='text').single_string())

    print("\n>>> PROCESO COMPLETADO CON ÉXITO <<<\n")

if __name__ == "__main__":
    main()
