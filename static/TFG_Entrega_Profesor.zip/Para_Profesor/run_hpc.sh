#!/bin/bash

echo "=========================================================="
echo "    EJECUCIÓN HPC: VQE GEMELO DIGITAL (GLICINA 20 QUBITS) "
echo "    Autor: Álvaro Zapata Beteta                             "
echo "=========================================================="
echo ""

# 1. Instalar dependencias si no están presentes (opcional, comentar si ya están)
echo "[INFO] Instalando dependencias desde requirements_hpc.txt..."
pip install -r requirements_hpc.txt -q

# 2. Prueba Estándar (Equilibrio: 4 Capas, 5000 Iteraciones)
echo ""
echo "[INFO] Iniciando Experimento 1: Prueba Estándar (4 capas, 5000 iters)"
echo "[INFO] Guardando resultados en: vqe_cfsim_estandar/"
python3 vqe_cfsim.py --layers 4 --iters 5000 --outdir vqe_cfsim_estandar

# 3. Prueba de Fuerza Bruta HPC (Alta Precisión: 6 Capas, 10000 Iteraciones)
echo ""
echo "[INFO] Iniciando Experimento 2: Fuerza Bruta HPC (6 capas, 10000 iters)"
echo "[INFO] Guardando resultados en: vqe_cfsim_bruto/"
python3 vqe_cfsim.py --layers 6 --iters 10000 --outdir vqe_cfsim_bruto

echo ""
echo "=========================================================="
echo " [OK] TODAS LAS SIMULACIONES HAN FINALIZADO CON ÉXITO."
echo " Revise las carpetas 'vqe_cfsim_estandar' y 'vqe_cfsim_bruto'."
echo "=========================================================="
