# Simulación VQE - Gemelo Digital (Glicina, 20 Qubits)
**Autor:** Álvaro Zapata Beteta

Estimado profesor,
Adjunto en esta carpeta todos los archivos necesarios para ejecutar la simulación del Trabajo de Fin de Grado en el clúster HPC. El código ha sido factorizado y depurado para su ejecución en entornos de alto rendimiento.

## 📁 Contenido de la carpeta
* `vqe_cfsim.py`: Script principal HPC-ready (con soporte de `argparse` y paralelización multihilo nativa de Qiskit).
* `active_space.fcidump`: Archivo con las integrales fermiónicas.
* `vqe_input.json`: Configuración de entrada (estado Hartree-Fock).
* `requirements_hpc.txt`: Dependencias puras del entorno.
* `run_hpc.sh`: Script automatizado para lanzar los experimentos sugeridos.

## 🚀 Cómo ejecutarlo

### Opción 1: Ejecución Automatizada (Recomendada)
He preparado un script bash que lanzará secuencialmente dos experimentos distintos para comparar el impacto del entrelazamiento y las iteraciones SPSA en el clúster.
Simplemente ejecute:
```bash
chmod +x run_hpc.sh
./run_hpc.sh
```
Esto generará dos carpetas (`vqe_cfsim_estandar/` y `vqe_cfsim_bruto/`) con los gráficos de convergencia y las topologías del circuito.

### Opción 2: Ejecución Manual Personalizada
Si desea probar configuraciones de capas o iteraciones específicas, puede usar los argumentos del script de Python:
```bash
pip install -r requirements_hpc.txt
python3 vqe_cfsim.py --layers <NUM_CAPAS> --iters <NUM_ITERACIONES> --outdir <CARPETA_SALIDA>
```
*Por ejemplo:* `python3 vqe_cfsim.py --layers 4 --iters 5000 --outdir prueba_1`

**Nota Técnica:** El motor de Qiskit `Statevector` aprovechará automáticamente el multithreading subyacente (vía `OMP_NUM_THREADS` / BLAS) en los nodos computacionales.

¡Muchas gracias por el soporte computacional para el TFG!
